/** Automatically generated file. DO NOT MODIFY */
package net.rdrei.android.dirchooser;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}