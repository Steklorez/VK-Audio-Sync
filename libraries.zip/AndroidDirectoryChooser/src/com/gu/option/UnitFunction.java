package com.gu.option;

public interface UnitFunction<T> {
   void apply(T x);
}
