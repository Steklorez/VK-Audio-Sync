package com.perm.kate.api;

public class Constants {

    //Privacy
    public static final String PrivacyAll = "0";	
    public static final String PrivacyOnlyFriends = "1";
    public static final String PrivacyAllFriends = "2";
    public static final String PrivacyOnlyMe = "3";

    //Comment privacy
    public static final String CommentPrivacyAll = "0";	
    public static final String CommentPrivacyOnlyFriends = "1";
    public static final String CommentPrivacyAllFriends = "2";
    public static final String CommentPrivacyOnlyMe = "3";

}
