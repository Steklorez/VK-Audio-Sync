package com.perm.kate.api;

import java.io.Serializable;

public class IdsPair implements Serializable {
    private static final long serialVersionUID = 1L;
    public long id;
    public long owner_id;
}
