package com.perm.kate.api;

public class NameCases {
    public static final String NOM = "nom"; //default
    public static final String GET = "gen";
    public static final String DAT = "dat";
    public static final String ACC = "acc";
    public static final String INS = "ins";
    public static final String ABL = "abl";
}
