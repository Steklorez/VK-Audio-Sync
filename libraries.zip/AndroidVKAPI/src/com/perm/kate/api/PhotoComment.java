package com.perm.kate.api;

public class PhotoComment {
    public Photo photo;
    public Comment comment;
}
