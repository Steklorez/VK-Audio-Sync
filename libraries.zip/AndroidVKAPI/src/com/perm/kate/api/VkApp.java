package com.perm.kate.api;

public class VkApp {
    public String app_id; 
    public String app_name; 
    public String src; 
    public String src_big;
}
