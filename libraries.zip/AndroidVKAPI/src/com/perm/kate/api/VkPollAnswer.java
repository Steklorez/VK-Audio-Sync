package com.perm.kate.api;

public class VkPollAnswer {
    public long id;
    public int votes;
    public String text;
    public int rate;
}
