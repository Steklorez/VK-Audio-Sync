package com.perm.kate.api;

public class VkStatus {
    public String text;
    public Audio audio;
}
