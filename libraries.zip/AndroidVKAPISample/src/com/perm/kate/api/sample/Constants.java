package com.perm.kate.api.sample;

public class Constants {
    //Этот ID предназначен только для примера. Пожалуйста замение его ID своего приложения.
    public static String API_ID="4701734";

}
