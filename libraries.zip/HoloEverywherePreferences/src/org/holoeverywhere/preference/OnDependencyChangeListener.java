
package org.holoeverywhere.preference;

interface OnDependencyChangeListener {
    void onDependencyChanged(Preference dependency, boolean disablesDependent);
}
