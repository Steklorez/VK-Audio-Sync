/** Automatically generated file. DO NOT MODIFY */
package uk.co.senab.actionbarpulltorefresh.extras.actionbarcompat;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}